import mysql.connector
mydb=mysql.connector.connect(host="local host",user="root",passwd="password123")
print(mydb)
if(mydb):
    print("successful")
else:
    print("unsuccessful")