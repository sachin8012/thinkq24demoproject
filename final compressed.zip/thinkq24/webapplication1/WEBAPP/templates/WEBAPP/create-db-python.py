import mysql.connector
mydb=mysql.connector.connect(host="127.0.0.1",user="root",passwd="password123",database="sachin",
auth_plugin="mysql_native_password")
cursor=mydb.cursor(buffered=True)
mycursor=mydb.cursor()
mycursor.execute("create table data1 (first_name varchar (200),last_name varchar(200),date_of_birth DATE)")