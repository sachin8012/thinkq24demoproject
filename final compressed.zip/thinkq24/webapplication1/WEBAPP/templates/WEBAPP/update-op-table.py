import mysql.connector
mydb=mysql.connector.connect(host="127.0.0.1",user="root",passwd="password123",database="sachin",
auth_plugin="mysql_native_password")
cursor=mydb.cursor(buffered=True)
mycursor=mydb.cursor()
sql="update data1 SET date_of_birth='1991-11-19' WHERE first_name='siva'"
mycursor.execute(sql)
mydb.commit()