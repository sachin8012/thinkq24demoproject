import mysql.connector
mydb=mysql.connector.connect(host="127.0.0.1",user="root",passwd="password123")

 mycursor =mydb.cursor()
 mycursor.execute("create db sachin")