import mysql.connector
mydb=mysql.connector.connect(host="127.0.0.1",user="root",passwd="password123",database="sachin",
auth_plugin="mysql_native_password")
cursor=mydb.cursor(buffered=True)
mycursor=mydb.cursor()
sqlform = "insert into data1(first_name,last_name,date_of_birth)values(%s,%s,%s)"
data1  = [("siva","sundarkumar",'1967-11-17'),("rithik","dinesh",'1877-11-18'),("salim","ram",'1865-12-16')]
mycursor.executemany(sqlform,data1)
mydb.commit()